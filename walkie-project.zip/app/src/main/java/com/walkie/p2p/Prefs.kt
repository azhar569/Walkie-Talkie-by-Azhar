package com.walkie.p2p

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val CHANNEL = "channel"
    const val NAME = "name"
    const val ROUTE = "route"        // 0 = headset mic+earbuds, 1 = earbuds + phone mic, 2 = phone
    const val HANDSFREE = "handsfree"
    const val SENS = "sens"
    const val LOWPOWER = "lowpower"
    const val MUTE = "mute"

    fun of(ctx: Context): SharedPreferences = ctx.getSharedPreferences("walkie", Context.MODE_PRIVATE)
}

/** Live status shared between the service and the UI (same process). */
object WalkieState {
    @Volatile var running = false
    @Volatile var status = "Stopped"
    @Volatile var peers: List<String> = emptyList()
    @Volatile var level = 0
    @Volatile var transmitting = false
    @Volatile var receivingFrom: String? = null
    @Volatile var route = ""

    @Volatile var listener: (() -> Unit)? = null
    private val main = android.os.Handler(android.os.Looper.getMainLooper())

    fun changed() {
        main.post { listener?.invoke() }
    }
}
