package com.walkie.p2p

import kotlin.math.sqrt

/**
 * Lightweight adaptive voice-activity detector (energy + zero-crossing rate).
 *
 *  - Tracks the ambient noise floor (falls fast, rises slowly) so it adapts to fans, traffic, wind.
 *  - Needs ONSET_FRAMES loud frames in a row to start (ignores clicks/bumps).
 *  - Hysteresis + hangover keeps the channel open through short pauses between words.
 *  - High zero-crossing rate (hiss, wind) is not treated as speech.
 *
 * Feed it 20 ms frames at 16 kHz. Costs a few microseconds per frame.
 */
class VoiceDetector {
    companion object {
        private const val ONSET_FRAMES = 3      // 60 ms of speech to open
        private const val HANGOVER_FRAMES = 25  // 500 ms to close
        private const val MAX_ZCR = 0.35       // hiss / wind / static: too "buzzy" to be a voice
        private const val STEADY_FRAMES = 150   // 3 s of unchanging loudness = background noise, not speech
    }

    /** 0..100, higher = opens on quieter speech. */
    @Volatile
    var sensitivity = 60

    private var floor = 150.0
    private var active = false
    private var onset = 0
    private var hang = 0
    private var avg = 0.0       // slow average loudness while open
    private var dev = 0.0       // slow average deviation from it
    private var steady = 0

    /** RMS of the last frame (0..32767), for the level meter. */
    var lastRms = 0.0
        private set

    fun reset() {
        active = false
        onset = 0
        hang = 0
        steady = 0
    }

    /** Returns true while the user is considered to be speaking. */
    fun process(frame: ShortArray, off: Int, len: Int): Boolean {
        var sum = 0.0
        var zc = 0
        var prev = frame[off].toInt()
        for (i in off until off + len) {
            val s = frame[i].toInt()
            sum += s.toDouble() * s
            if ((s >= 0) != (prev >= 0)) zc++
            prev = s
        }
        val rms = sqrt(sum / len)
        val zcr = zc.toDouble() / len
        lastRms = rms

        val k = sensitivity.coerceIn(0, 100) / 100.0
        val ratio = 6.0 - 4.0 * k          // 6x floor (low sens) .. 2x floor (high sens)
        val minAbs = 450.0 - 300.0 * k     // absolute minimum RMS to ever count as speech
        val startThr = maxOf(minAbs, floor * ratio)
        val stayThr = maxOf(minAbs * 0.6, floor * ratio * 0.6)

        if (!active) {
            if (rms < startThr) {
                // Learn the background: drop fast, rise slowly.
                floor += (rms - floor) * (if (rms < floor) 0.3 else 0.02)
                if (floor < 20.0) floor = 20.0
            }
            if (rms > startThr && zcr < MAX_ZCR) onset++ else onset = 0
            if (onset >= ONSET_FRAMES) {
                active = true
                hang = HANGOVER_FRAMES
                onset = 0
                avg = rms
                dev = rms * 0.5
                steady = 0
            }
        } else {
            if (rms > stayThr) {
                hang = HANGOVER_FRAMES
            } else if (--hang <= 0) {
                active = false
            }
            // Real speech is bursty. If the loudness stays almost perfectly constant for seconds it is
            // a hum / engine / fan: learn it as the new background and close, instead of staying open.
            dev += (Math.abs(rms - avg) - dev) * 0.05
            avg += (rms - avg) * 0.05
            if (dev < avg * 0.12) steady++ else steady = 0
            if (steady >= STEADY_FRAMES) {
                floor = maxOf(floor, avg)
                active = false
                steady = 0
            }
        }
        return active
    }
}
