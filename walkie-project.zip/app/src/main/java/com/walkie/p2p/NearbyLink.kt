package com.walkie.p2p

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import java.util.concurrent.ConcurrentHashMap
import kotlin.random.Random

/**
 * Offline peer-to-peer link (Google Nearby Connections, P2P_CLUSTER = many-to-many mesh).
 * Works with no internet and no router: it uses Bluetooth / BLE and upgrades to Wi-Fi when needed.
 * All devices on the same "channel" code find each other and connect automatically.
 *
 * Battery:
 *  - Always advertises (cheap), but discovery (the expensive scan) is duty-cycled once connected:
 *    8 s on / 45 s off (120 s off when the battery is low or low-power mode is on).
 *  - Optional low-power mode restricts the link to Bluetooth only (no Wi-Fi radio).
 */
class NearbyLink(
    ctx: Context,
    private val cb: Callback,
    private val powerSaver: () -> Boolean
) {
    interface Callback {
        fun onPeers(peers: Map<String, String>)
        fun onAudio(peerId: String, data: ByteArray)
        fun onStatus(msg: String)
    }

    private val client = Nearby.getConnectionsClient(ctx.applicationContext)
    private val main = Handler(Looper.getMainLooper())

    private val connected = ConcurrentHashMap<String, String>() // endpointId -> display name
    private val pending = HashSet<String>()
    private val remoteNames = HashMap<String, String>()
    private val found = HashMap<String, String>()

    private var running = false
    private var discovering = false
    private var serviceId = ""
    private var localName = ""
    private var myUid = ""
    private var lowPower = false

    fun start(channel: String, displayName: String, lowPower: Boolean) {
        if (running) return
        running = true
        this.lowPower = lowPower
        serviceId = "walkie." + channel.trim().lowercase().replace(Regex("[^a-z0-9]"), "_").ifEmpty { "default" }
        myUid = Random.nextInt(0x100000, 0xFFFFFF).toString(16)
        localName = "$myUid|${displayName.trim().ifEmpty { "Walkie" }.take(24)}"

        client.startAdvertising(
            localName, serviceId, lifecycle,
            AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).setLowPower(lowPower).build()
        ).addOnFailureListener { e ->
            if (!already(e)) cb.onStatus("Cannot advertise: ${e.message}")
        }
        main.post(cycle)
        cb.onStatus("Looking for people on channel \"$channel\"")
    }

    fun stop() {
        if (!running) return
        running = false
        main.removeCallbacksAndMessages(null)
        try {
            client.stopAdvertising()
            client.stopDiscovery()
            client.stopAllEndpoints()
        } catch (_: Exception) {
        }
        discovering = false
        connected.clear()
        pending.clear()
        found.clear()
        remoteNames.clear()
        cb.onPeers(emptyMap())
    }

    fun send(bytes: ByteArray) {
        if (connected.isEmpty()) return
        client.sendPayload(ArrayList(connected.keys), Payload.fromBytes(bytes))
    }

    // ---- discovery duty cycle --------------------------------------------------------------

    private val cycle = object : Runnable {
        override fun run() {
            if (!running) return
            val save = powerSaver() || lowPower
            if (connected.isEmpty()) {
                if (!discovering) startDiscovery()
                main.postDelayed(this, 10_000)
            } else if (discovering) {
                stopDiscovery()
                main.postDelayed(this, if (save) 120_000L else 45_000L)
            } else {
                startDiscovery()
                main.postDelayed(this, 8_000)
            }
        }
    }

    private fun startDiscovery() {
        discovering = true
        client.startDiscovery(
            serviceId, discoveryCb,
            DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).setLowPower(lowPower).build()
        ).addOnFailureListener { e ->
            if (!already(e)) {
                discovering = false
                cb.onStatus("Cannot scan: ${e.message}")
            }
        }
    }

    private fun stopDiscovery() {
        discovering = false
        try {
            client.stopDiscovery()
        } catch (_: Exception) {
        }
    }

    private fun already(e: Exception): Boolean {
        val code = (e as? ApiException)?.statusCode
        return code == ConnectionsStatusCodes.STATUS_ALREADY_ADVERTISING ||
            code == ConnectionsStatusCodes.STATUS_ALREADY_DISCOVERING
    }

    // ---- connecting ------------------------------------------------------------------------

    private val discoveryCb = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            found[id] = info.endpointName
            if (connected.containsKey(id) || pending.contains(id)) return
            // Tie-break so both phones don't request at once: the lower id asks immediately,
            // the other waits and only asks if nothing happened.
            val theirUid = info.endpointName.substringBefore('|')
            val delay = when {
                myUid < theirUid -> 0L
                connected.isEmpty() -> 2500L + Random.nextLong(1500)
                else -> 15_000L + Random.nextLong(5000)
            }
            main.postDelayed({ tryRequest(id) }, delay)
        }

        override fun onEndpointLost(id: String) {
            found.remove(id)
        }
    }

    private fun tryRequest(id: String) {
        if (!running || connected.containsKey(id) || pending.contains(id) || !found.containsKey(id)) return
        pending.add(id)
        client.requestConnection(localName, id, lifecycle).addOnFailureListener {
            pending.remove(id)
            main.postDelayed({ tryRequest(id) }, 8000)
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            pending.add(id)
            remoteNames[id] = info.endpointName
            // Only devices using the same channel code can ever reach this point (serviceId is derived
            // from it), and the link itself is encrypted by Nearby Connections.
            client.acceptConnection(id, payloadCb)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            pending.remove(id)
            if (result.status.isSuccess) {
                connected[id] = displayName(remoteNames[id] ?: id)
                publish()
            }
        }

        override fun onDisconnected(id: String) {
            connected.remove(id)
            pending.remove(id)
            if (!running) return
            publish()
            if (connected.isEmpty()) { // find people again right away
                main.removeCallbacks(cycle)
                main.post(cycle)
            }
        }
    }

    private fun displayName(raw: String) = raw.substringAfter('|', raw)

    private fun publish() {
        cb.onPeers(HashMap(connected))
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            if (payload.type == Payload.Type.BYTES) {
                payload.asBytes()?.let { cb.onAudio(id, it) }
            }
        }

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {}
    }
}
