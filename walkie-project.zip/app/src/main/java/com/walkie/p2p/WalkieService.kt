package com.walkie.p2p

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.AudioEffect
import android.media.audiofx.NoiseSuppressor
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import java.util.concurrent.Executors
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import kotlin.math.log10

/**
 * Foreground service that owns the whole walkie-talkie:
 *   microphone -> voice detector -> ADPCM -> Nearby link -> peers      (talking)
 *   Nearby link -> ADPCM decode -> jitter buffer/mixer -> speaker      (listening)
 *
 * Battery strategy
 *  - Nothing audio-related runs until at least one peer is connected (alone = radio scan only).
 *  - Microphone is only open when hands-free is on or the talk button is held (and not muted).
 *  - Silence is never encoded or sent: the radio only transmits while someone is speaking.
 *  - 40 ms packets (25 radio wake-ups/s while talking, none while quiet).
 *  - Discovery scan is duty-cycled once connected; wake lock only held while connected.
 *  - Playback thread and speaker sleep when nobody is talking.
 */
class WalkieService : Service(), NearbyLink.Callback {

    companion object {
        const val ACTION_STOP = "com.walkie.p2p.STOP"
        private const val CHANNEL_ID = "walkie"
        private const val NOTIF_ID = 1
        private const val PKT_AUDIO: Byte = 0x41

        @Volatile private var instance: WalkieService? = null

        @Volatile var pttHeld = false
            private set

        fun setPtt(on: Boolean) {
            pttHeld = on
            instance?.signal?.release()
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private val pipelineExec = Executors.newSingleThreadExecutor()
    private val decodeExec = Executors.newSingleThreadExecutor()
    private val signal = Semaphore(0)

    private lateinit var prefs: SharedPreferences
    private lateinit var router: AudioRouter
    private var link: NearbyLink? = null

    // Touched only on pipelineExec
    private var pipelineOn = false
    private var capture: CaptureThread? = null
    private var playback: PlaybackEngine? = null
    private var wakeLock: PowerManager.WakeLock? = null

    @Volatile private var effRoute = Route.PHONE
    @Volatile private var halfDuplex = true
    @Volatile private var peers: Map<String, String> = emptyMap()
    @Volatile private var handsFree = true
    @Volatile private var muted = false
    @Volatile private var sensitivity = 60

    private var started = false

    // ------------------------------------------------------------------------------------
    // lifecycle
    // ------------------------------------------------------------------------------------

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (started) return START_NOT_STICKY
        started = true
        instance = this
        createChannel()
        val n = buildNotification("Starting...")
        try {
            if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                throw SecurityException("microphone permission missing")
            }
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(
                    NOTIF_ID, n,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE or ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE
                )
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            WalkieState.status = "Cannot start: ${e.message}"
            WalkieState.changed()
            stopSelf()
            return START_NOT_STICKY
        }
        init()
        return START_NOT_STICKY
    }

    private fun init() {
        prefs = Prefs.of(this)
        router = AudioRouter(this)
        loadSettings()
        prefs.registerOnSharedPreferenceChangeListener(prefListener)
        (getSystemService(Context.AUDIO_SERVICE) as AudioManager).registerAudioDeviceCallback(devCb, main)

        WalkieState.running = true
        WalkieState.status = "Starting..."
        WalkieState.changed()
        startLink()
    }

    private fun startLink() {
        val l = NearbyLink(this, this) { batteryLow() }
        link = l
        l.start(
            prefs.getString(Prefs.CHANNEL, "walkie1") ?: "walkie1",
            prefs.getString(Prefs.NAME, Build.MODEL) ?: Build.MODEL,
            prefs.getBoolean(Prefs.LOWPOWER, false)
        )
    }

    @Volatile private var stopping = false

    override fun onDestroy() {
        stopping = true
        try {
            prefs.unregisterOnSharedPreferenceChangeListener(prefListener)
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).unregisterAudioDeviceCallback(devCb)
        } catch (_: Exception) {
        }
        main.removeCallbacksAndMessages(null)
        link?.stop()
        link = null
        pipelineExec.execute { if (pipelineOn) stopPipelineSync() }
        pipelineExec.shutdown()
        decodeExec.shutdown()
        WalkieState.running = false
        WalkieState.status = "Stopped"
        WalkieState.peers = emptyList()
        WalkieState.level = 0
        WalkieState.transmitting = false
        WalkieState.receivingFrom = null
        WalkieState.route = ""
        WalkieState.changed()
        pttHeld = false
        instance = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }

    // ------------------------------------------------------------------------------------
    // settings
    // ------------------------------------------------------------------------------------

    private fun loadSettings() {
        handsFree = prefs.getBoolean(Prefs.HANDSFREE, true)
        muted = prefs.getBoolean(Prefs.MUTE, false)
        sensitivity = prefs.getInt(Prefs.SENS, 60)
    }

    private fun desiredRoute(): Route =
        Route.values()[prefs.getInt(Prefs.ROUTE, 0).coerceIn(0, Route.values().size - 1)]

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        loadSettings()
        when (key) {
            Prefs.ROUTE -> restartPipeline()
            Prefs.LOWPOWER -> {
                link?.stop()
                startLink()
            }
            else -> signal.release()
        }
    }

    // ------------------------------------------------------------------------------------
    // peers
    // ------------------------------------------------------------------------------------

    override fun onPeers(peers: Map<String, String>) {
        this.peers = peers
        WalkieState.peers = peers.values.toList()
        val text = when {
            peers.isEmpty() -> "Looking for people on your channel"
            peers.size == 1 -> "Connected to ${peers.values.first()}"
            else -> "Connected to ${peers.size} people"
        }
        WalkieState.status = text
        WalkieState.changed()
        if (!stopping) updateNotification(text)
        if (peers.isNotEmpty()) {
            pipelineExec.execute { if (!pipelineOn) startPipelineSync() }
        } else {
            pipelineExec.execute { if (pipelineOn) stopPipelineSync() }
        }
        signal.release()
    }

    override fun onStatus(msg: String) {
        if (peers.isEmpty()) {
            WalkieState.status = msg
            WalkieState.changed()
        }
    }

    // ------------------------------------------------------------------------------------
    // receiving
    // ------------------------------------------------------------------------------------

    private val clearRx = Runnable {
        WalkieState.receivingFrom = null
        WalkieState.changed()
    }

    override fun onAudio(peerId: String, data: ByteArray) {
        decodeExec.execute {
            if (data.size <= 3 + Adpcm.HEADER || data[0] != PKT_AUDIO) return@execute
            val pcm = ShortArray((data.size - 3 - Adpcm.HEADER) * 2)
            if (Adpcm.decode(data, 3, data.size - 3, pcm) != Audio.CHUNK) return@execute
            playback?.enqueue(peerId, pcm)
            val name = peers[peerId] ?: return@execute
            main.post {
                if (WalkieState.receivingFrom != name) {
                    WalkieState.receivingFrom = name
                    WalkieState.changed()
                }
                main.removeCallbacks(clearRx)
                main.postDelayed(clearRx, 700)
            }
        }
    }

    // ------------------------------------------------------------------------------------
    // audio pipeline (runs on pipelineExec)
    // ------------------------------------------------------------------------------------

    private fun startPipelineSync() {
        pipelineOn = true
        val eff = router.apply(desiredRoute())
        effRoute = eff
        halfDuplex = eff == Route.PHONE || (eff == Route.EARBUDS && !router.hasBluetoothAudio())
        WalkieState.route = when (eff) {
            Route.HEADSET -> "Bluetooth headset (mic + speaker)"
            Route.EARBUDS -> if (halfDuplex) "Phone speaker + mic (no earbuds found)" else "Earbuds + phone mic"
            Route.PHONE -> if (desiredRoute() == Route.HEADSET) "Phone speaker + mic (no headset found)" else "Phone speaker + mic"
        }
        WalkieState.changed()
        val usage = if (eff == Route.EARBUDS) AudioAttributes.USAGE_MEDIA else AudioAttributes.USAGE_VOICE_COMMUNICATION
        playback = PlaybackEngine(usage).also { it.start() }
        capture = CaptureThread().also { it.start() }
        acquireWake()
    }

    private fun stopPipelineSync() {
        pipelineOn = false
        capture?.let {
            it.quit = true
            signal.release()
            try {
                it.join(1500)
            } catch (_: InterruptedException) {
            }
        }
        capture = null
        playback?.stop()
        playback = null
        router.release()
        releaseWake()
        WalkieState.transmitting = false
        WalkieState.level = 0
        WalkieState.route = ""
        WalkieState.changed()
    }

    private fun restartPipeline() {
        pipelineExec.execute {
            if (pipelineOn) {
                stopPipelineSync()
                startPipelineSync()
            }
        }
    }

    // Earbuds put in / taken out: re-route automatically (debounced).
    private var devAdded = false
    private val devRestart = Runnable {
        pipelineExec.execute {
            if (!pipelineOn) return@execute
            val want = desiredRoute()
            val needs = when (want) {
                Route.HEADSET -> if (devAdded) effRoute != Route.HEADSET else effRoute == Route.HEADSET
                Route.EARBUDS -> true
                Route.PHONE -> false
            }
            if (needs) {
                stopPipelineSync()
                startPipelineSync()
            }
        }
    }

    private val devCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = changed(addedDevices, true)
        override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = changed(removedDevices, false)

        private fun changed(d: Array<out AudioDeviceInfo>?, added: Boolean) {
            if (d == null || d.none { AudioRouter.isBtType(it.type) }) return
            devAdded = added
            main.removeCallbacks(devRestart)
            main.postDelayed(devRestart, 800)
        }
    }

    // ------------------------------------------------------------------------------------
    // capture + voice detection + send
    // ------------------------------------------------------------------------------------

    private fun captureNeeded(): Boolean = peers.isNotEmpty() && !muted && (handsFree || pttHeld)

    private inner class CaptureThread : Thread("walkie-capture") {
        @Volatile var quit = false

        override fun run() {
            val chunk = ShortArray(Audio.CHUNK)
            val detector = VoiceDetector()
            val encoder = Adpcm.Encoder()
            val preroll = ArrayDeque<ShortArray>()   // last ~120 ms so the first syllable is not clipped
            var rec: AudioRecord? = null
            val effects = ArrayList<AudioEffect>()
            var talking = false
            var seq = 0
            var tick = 0

            fun closeMic() {
                effects.forEach { try { it.release() } catch (_: Exception) {} }
                effects.clear()
                try { rec?.stop() } catch (_: Exception) {}
                try { rec?.release() } catch (_: Exception) {}
                rec = null
                preroll.clear()
                detector.reset()
                if (talking) {
                    talking = false
                    WalkieState.transmitting = false
                }
                WalkieState.level = 0
                WalkieState.changed()
            }

            fun transmit(pcm: ShortArray) {
                val pkt = ByteArray(3 + Adpcm.HEADER + Audio.CHUNK / 2)
                pkt[0] = PKT_AUDIO
                pkt[1] = (seq and 0xFF).toByte()
                pkt[2] = ((seq shr 8) and 0xFF).toByte()
                seq++
                encoder.encode(pcm, Audio.CHUNK, pkt, 3)
                link?.send(pkt)
            }

            try {
                while (!quit) {
                    if (!captureNeeded()) {
                        if (rec != null) closeMic()
                        signal.drainPermits()
                        signal.tryAcquire(2, TimeUnit.SECONDS)
                        continue
                    }

                    if (rec == null) {
                        rec = openMic(effects)
                        if (rec == null) {
                            WalkieState.status = "Microphone unavailable - is another app using it?"
                            WalkieState.changed()
                            signal.drainPermits()
                            signal.tryAcquire(2, TimeUnit.SECONDS)
                            continue
                        }
                    }

                    val r = rec ?: continue
                    var got = 0
                    while (got < Audio.CHUNK && !quit) {
                        val n = r.read(chunk, got, Audio.CHUNK - got)
                        if (n < 0) break
                        got += n
                    }
                    if (got < Audio.CHUNK) {
                        closeMic()
                        continue
                    }

                    val ptt = pttHeld
                    detector.sensitivity = sensitivity
                    // Loudspeaker mode: ignore the mic while the other side is being played (avoids echo loops).
                    val blocked = halfDuplex && !ptt && playback?.isActive() == true
                    var voice = false
                    if (blocked) {
                        detector.reset()
                    } else {
                        for (k in 0 until Audio.CHUNK / Audio.SUB) {
                            if (detector.process(chunk, k * Audio.SUB, Audio.SUB)) voice = true
                        }
                    }

                    if (++tick % 5 == 0) {
                        val db = 20 * log10(detector.lastRms + 1.0)
                        WalkieState.level = ((db - 30) / 50 * 100).toInt().coerceIn(0, 100)
                        WalkieState.changed()
                    }

                    val send = ptt || (handsFree && voice)
                    if (send) {
                        if (!talking) {
                            talking = true
                            encoder.reset()
                            WalkieState.transmitting = true
                            WalkieState.changed()
                            while (preroll.isNotEmpty()) transmit(preroll.removeFirst())
                        }
                        transmit(chunk.copyOf())
                    } else {
                        if (talking) {
                            talking = false
                            WalkieState.transmitting = false
                            WalkieState.changed()
                        }
                        preroll.addLast(chunk.copyOf())
                        while (preroll.size > 3) preroll.removeFirst()
                    }
                }
            } catch (_: Exception) {
            } finally {
                closeMic()
            }
        }
    }

    private fun openMic(effects: MutableList<AudioEffect>): AudioRecord? {
        return try {
            val eff = effRoute
            val source = if (eff == Route.EARBUDS) MediaRecorder.AudioSource.MIC
            else MediaRecorder.AudioSource.VOICE_COMMUNICATION
            val min = AudioRecord.getMinBufferSize(
                Audio.RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(Audio.RATE)
                        .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                        .build()
                )
                .setBufferSizeInBytes(maxOf(min, Audio.CHUNK * 2 * 4))
                .build()
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                rec.release()
                return null
            }
            if (eff == Route.HEADSET) router.bluetoothInput()?.let { rec.setPreferredDevice(it) }
            try {
                if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(rec.audioSessionId)?.let { effects.add(it) }
                if (halfDuplex && AcousticEchoCanceler.isAvailable()) {
                    AcousticEchoCanceler.create(rec.audioSessionId)?.let { effects.add(it) }
                }
                effects.forEach { it.setEnabled(true) }
            } catch (_: Exception) {
            }
            rec.startRecording()
            if (rec.recordingState != AudioRecord.RECORDSTATE_RECORDING) {
                rec.release()
                return null
            }
            rec
        } catch (_: Exception) {
            null
        }
    }

    // ------------------------------------------------------------------------------------
    // power
    // ------------------------------------------------------------------------------------

    private fun acquireWake() {
        if (wakeLock?.isHeld == true) return
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "walkie:audio").apply {
            setReferenceCounted(false)
            acquire()
        }
    }

    private fun releaseWake() {
        try {
            if (wakeLock?.isHeld == true) wakeLock?.release()
        } catch (_: Exception) {
        }
        wakeLock = null
    }

    private fun batteryLow(): Boolean {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return false
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
        return !charging && level >= 0 && level * 100 / scale <= 20
    }

    // ------------------------------------------------------------------------------------
    // notification
    // ------------------------------------------------------------------------------------

    private fun createChannel() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Walkie running", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(text: String): Notification {
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, WalkieService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Offline Walkie")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    android.graphics.drawable.Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Stop", stop
                ).build()
            )
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
