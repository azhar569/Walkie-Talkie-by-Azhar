package com.walkie.p2p

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.CompoundButton
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val bg = Color.parseColor("#0F1115")
    private val card = Color.parseColor("#1A1D24")
    private val textMain = Color.parseColor("#E8EAED")
    private val textDim = Color.parseColor("#9AA0A6")
    private val green = Color.parseColor("#4ADE80")
    private val red = Color.parseColor("#F87171")
    private val blue = Color.parseColor("#60A5FA")

    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var channel: EditText
    private lateinit var name: EditText
    private lateinit var status: TextView
    private lateinit var peersText: TextView
    private lateinit var routeText: TextView
    private lateinit var meter: ProgressBar
    private lateinit var startBtn: Button
    private lateinit var talkBtn: Button
    private lateinit var activity: TextView

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs.of(this)
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        WalkieState.listener = { render() }
        render()
    }

    override fun onStop() {
        WalkieState.listener = null
        super.onStop()
    }

    // ---------------------------------------------------------------------------------------

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(28))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(bg)
            isFillViewport = true
            addView(root)
        }
        setContentView(scroll)

        root.addView(text("Offline Walkie", 26f, textMain, bold = true))
        root.addView(text("Hands-free voice between phones. No internet, no SIM, no router.", 13f, textDim).also {
            it.setPadding(0, dp(2), 0, dp(14))
        })

        // --- status card
        val statusCard = card().also { root.addView(it) }
        status = text("Stopped", 17f, textMain, bold = true)
        peersText = text("", 14f, textDim)
        routeText = text("", 13f, textDim)
        activity = text(" ", 15f, green, bold = true)
        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progressTintList = android.content.res.ColorStateList.valueOf(green)
        }
        statusCard.addView(status)
        statusCard.addView(peersText)
        statusCard.addView(routeText)
        statusCard.addView(activity)
        statusCard.addView(meter, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(10)).apply {
            topMargin = dp(8)
        })

        // --- start/stop
        startBtn = button("Start", green, Color.BLACK).apply {
            setOnClickListener { toggle() }
        }
        root.addView(startBtn, lp(top = 14, height = 56))

        // --- push to talk
        talkBtn = button("Hold to talk", blue, Color.BLACK)
        talkBtn.setOnTouchListener { _, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> WalkieService.setPtt(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> WalkieService.setPtt(false)
            }
            true
        }
        root.addView(talkBtn, lp(top = 10, height = 72))

        // --- settings card
        val s = card().also { root.addView(it, lp(top = 16)) }
        s.addView(text("Channel code", 13f, textDim))
        channel = edit(prefs.getString(Prefs.CHANNEL, "walkie1") ?: "walkie1")
        s.addView(channel)
        s.addView(text("Everyone who types the same code joins the same channel.", 12f, textDim))
        s.addView(text("Your name", 13f, textDim).also { it.setPadding(0, dp(12), 0, 0) })
        name = edit(prefs.getString(Prefs.NAME, Build.MODEL) ?: Build.MODEL)
        s.addView(name)

        val s2 = card().also { root.addView(it, lp(top = 12)) }
        s2.addView(text("Audio output / microphone", 13f, textDim))
        val group = RadioGroup(this).apply { orientation = LinearLayout.VERTICAL }
        val labels = listOf(
            "Earbuds mic + earbuds (hands-free)",
            "Earbuds sound + phone mic (saves earbud battery)",
            "Phone speaker + phone mic"
        )
        val current = prefs.getInt(Prefs.ROUTE, 0)
        labels.forEachIndexed { i, l ->
            group.addView(RadioButton(this).apply {
                id = 100 + i
                text = l
                setTextColor(textMain)
                textSize = 14f
                isChecked = i == current
            })
        }
        group.setOnCheckedChangeListener { _, id -> prefs.edit().putInt(Prefs.ROUTE, id - 100).apply() }
        s2.addView(group)

        val s3 = card().also { root.addView(it, lp(top = 12)) }
        s3.addView(switchRow("Hands-free (auto-detect my voice)", Prefs.HANDSFREE, true))
        s3.addView(text("Voice sensitivity", 13f, textDim).also { it.setPadding(0, dp(10), 0, 0) })
        s3.addView(SeekBar(this).apply {
            max = 100
            progress = prefs.getInt(Prefs.SENS, 60)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) prefs.edit().putInt(Prefs.SENS, p).apply()
                }

                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        })
        s3.addView(text("Higher = opens on quieter speech. Lower = ignores more background noise.", 12f, textDim))
        s3.addView(switchRow("Mute my microphone", Prefs.MUTE, false).also { it.setPadding(0, dp(10), 0, 0) })

        val s4 = card().also { root.addView(it, lp(top = 12)) }
        s4.addView(switchRow("Low-power link (Bluetooth only, shorter range)", Prefs.LOWPOWER, false))
        s4.addView(text("Turns off the Wi-Fi radio for the connection. Best for people close together.", 12f, textDim))
    }

    private fun toggle() {
        if (WalkieState.running) {
            startService(Intent(this, WalkieService::class.java).setAction(WalkieService.ACTION_STOP))
            return
        }
        val missing = requiredPermissions().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 7)
        } else {
            startWalkie()
        }
    }

    private fun requiredPermissions(): List<String> {
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 31) {
            p += Manifest.permission.BLUETOOTH_SCAN
            p += Manifest.permission.BLUETOOTH_ADVERTISE
            p += Manifest.permission.BLUETOOTH_CONNECT
        }
        if (Build.VERSION.SDK_INT <= 32) p += Manifest.permission.ACCESS_FINE_LOCATION
        if (Build.VERSION.SDK_INT >= 33) {
            p += Manifest.permission.NEARBY_WIFI_DEVICES
            p += Manifest.permission.POST_NOTIFICATIONS
        }
        return p
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        if (code != 7) return
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val core = requiredPermissions().filter { it != Manifest.permission.POST_NOTIFICATIONS }
            .all { checkSelfPermission(it) == PackageManager.PERMISSION_GRANTED }
        if (mic && core) {
            startWalkie()
        } else {
            Toast.makeText(
                this, "Walkie needs microphone and nearby-devices permission to work.", Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun startWalkie() {
        prefs.edit()
            .putString(Prefs.CHANNEL, channel.text.toString().trim().ifEmpty { "walkie1" })
            .putString(Prefs.NAME, name.text.toString().trim().ifEmpty { Build.MODEL })
            .apply()
        startForegroundService(Intent(this, WalkieService::class.java))
    }

    // ---------------------------------------------------------------------------------------

    private fun render() {
        val running = WalkieState.running
        startBtn.text = if (running) "Stop" else "Start"
        (startBtn.background as? GradientDrawable)?.setColor(if (running) red else green)
        channel.isEnabled = !running
        name.isEnabled = !running
        status.text = WalkieState.status
        val p = WalkieState.peers
        peersText.text = if (p.isEmpty()) "" else "On channel: " + p.joinToString(", ")
        routeText.text = WalkieState.route
        meter.progress = WalkieState.level
        meter.visibility = if (running && WalkieState.route.isNotEmpty()) View.VISIBLE else View.INVISIBLE
        val rx = WalkieState.receivingFrom
        when {
            WalkieState.transmitting -> {
                activity.text = "Transmitting..."
                activity.setTextColor(red)
            }
            rx != null -> {
                activity.text = "$rx is talking"
                activity.setTextColor(green)
            }
            else -> activity.text = " "
        }
        talkBtn.alpha = if (running && p.isNotEmpty()) 1f else 0.4f
    }

    // ---- tiny view helpers --------------------------------------------------------------------

    private fun lp(top: Int = 0, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT) =
        LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            if (height > 0) dp(height) else height
        ).apply { topMargin = dp(top) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(card)
            cornerRadius = dp(16).toFloat()
        }
    }

    private fun text(t: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun edit(value: String) = EditText(this).apply {
        setText(value)
        setTextColor(textMain)
        setSingleLine()
        setHintTextColor(textDim)
    }

    private fun button(label: String, fill: Int, fg: Int) = Button(this).apply {
        text = label
        textSize = 18f
        isAllCaps = false
        setTextColor(fg)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        background = GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(16).toFloat()
        }
    }

    @SuppressLint("UseSwitchCompatOrMaterialCode")
    private fun switchRow(label: String, key: String, default: Boolean) = Switch(this).apply {
        text = label
        textSize = 15f
        setTextColor(textMain)
        isChecked = prefs.getBoolean(key, default)
        setOnCheckedChangeListener { _: CompoundButton, on: Boolean ->
            prefs.edit().putBoolean(key, on).apply()
        }
    }
}
