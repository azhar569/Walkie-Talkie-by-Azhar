package com.walkie.p2p

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.TimeUnit
import java.util.concurrent.locks.ReentrantLock
import kotlin.concurrent.withLock

/**
 * Plays incoming voice. Keeps one small jitter buffer per talker and mixes talkers together.
 * Battery: the thread sleeps on a condition (zero CPU) until audio arrives, and the AudioTrack is
 * paused after one second of silence.
 */
class PlaybackEngine(private val usage: Int) {
    companion object {
        private const val PREBUF = 2          // frames (80 ms) buffered before a talker starts playing
        private const val MAX_Q = 12          // if a talker's backlog exceeds this (~480 ms)...
        private const val TRIM_TO = 4         // ...drop old audio to catch up and keep latency low
        private const val IDLE_MS = 1000
    }

    private class PeerQ {
        val frames = ArrayDeque<ShortArray>()
        var buffering = true
        var lastRx = System.nanoTime()
    }

    private val lock = ReentrantLock()
    private val hasData = lock.newCondition()
    private val peers = HashMap<String, PeerQ>()

    @Volatile private var running = false
    @Volatile private var lastAudioNs = 0L
    private var thread: Thread? = null

    fun start() {
        if (running) return
        running = true
        thread = Thread({ loop() }, "walkie-playback").also { it.start() }
    }

    fun stop() {
        running = false
        lock.withLock { hasData.signalAll() }
        try {
            thread?.join(1500)
        } catch (_: InterruptedException) {
        }
    }

    /** True while received audio is being played (and shortly after) - used to avoid echo on loudspeaker. */
    fun isActive(): Boolean = System.nanoTime() - lastAudioNs < 450_000_000L

    fun enqueue(peer: String, pcm: ShortArray) {
        lock.withLock {
            val q = peers.getOrPut(peer) { PeerQ() }
            q.lastRx = System.nanoTime()
            q.frames.addLast(pcm)
            if (q.frames.size > MAX_Q) {
                while (q.frames.size > TRIM_TO) q.frames.removeFirst()
            }
            hasData.signal()
        }
    }

    private fun buildTrack(): AudioTrack {
        val min = AudioTrack.getMinBufferSize(
            Audio.RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val size = maxOf(min, Audio.CHUNK * 2 * 3)
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(usage)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(Audio.RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .build()
            )
            .setBufferSizeInBytes(size)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
    }

    private fun loop() {
        var track: AudioTrack? = null
        val acc = IntArray(Audio.CHUNK)
        val mix = ShortArray(Audio.CHUNK)
        try {
            while (running) {
                // Sleep (no CPU) until something arrives.
                lock.withLock {
                    while (running && peers.values.none { it.frames.isNotEmpty() }) {
                        hasData.await(1, TimeUnit.SECONDS)
                    }
                }
                if (!running) break
                val t = track ?: buildTrack().also { track = it }
                t.play()
                var idle = 0
                while (running && idle < IDLE_MS) {
                    java.util.Arrays.fill(acc, 0)
                    var any = false
                    lock.withLock {
                        val now = System.nanoTime()
                        val iter = peers.entries.iterator()
                        while (iter.hasNext()) {
                            val q = iter.next().value
                            if (q.buffering && q.frames.size >= PREBUF) q.buffering = false
                            if (!q.buffering) {
                                val f = q.frames.removeFirstOrNull()
                                if (f != null) {
                                    for (i in 0 until Audio.CHUNK) acc[i] += f[i]
                                    any = true
                                } else {
                                    q.buffering = true
                                }
                            }
                            if (q.frames.isEmpty() && now - q.lastRx > 3_000_000_000L) iter.remove()
                        }
                    }
                    if (any) {
                        for (i in 0 until Audio.CHUNK) mix[i] = acc[i].coerceIn(-32768, 32767).toShort()
                        t.write(mix, 0, Audio.CHUNK) // blocks until the hardware needs more: natural pacing
                        lastAudioNs = System.nanoTime()
                        idle = 0
                    } else {
                        Thread.sleep(15)
                        idle += 15
                    }
                }
                try {
                    t.pause()
                    t.flush()
                } catch (_: IllegalStateException) {
                }
            }
        } catch (_: InterruptedException) {
        } finally {
            try {
                track?.release()
            } catch (_: Exception) {
            }
        }
    }
}
