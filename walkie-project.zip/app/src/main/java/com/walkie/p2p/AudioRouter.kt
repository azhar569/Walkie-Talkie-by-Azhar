package com.walkie.p2p

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioDeviceInfo
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build

/**
 * HEADSET  - earbuds mic + earbuds speaker over Bluetooth call audio (SCO / LE Audio). Hands-free, full duplex.
 * EARBUDS  - phone mic, earbuds play the sound over normal high-quality Bluetooth (A2DP).
 *            Keeps the earbuds' own mics off, which saves earbud battery.
 * PHONE    - phone loudspeaker + phone mic (half duplex so it does not hear itself).
 */
enum class Route { HEADSET, EARBUDS, PHONE }

@Suppress("DEPRECATION")
class AudioRouter(ctx: Context) {
    private val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private var focus: AudioFocusRequest? = null
    private var scoOn = false

    companion object {
        fun isBtType(type: Int): Boolean =
            type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET)

        fun isBtCommType(type: Int): Boolean =
            type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && type == AudioDeviceInfo.TYPE_BLE_HEADSET)
    }

    fun hasBluetoothAudio(): Boolean =
        am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).any { isBtType(it.type) }

    /** The headset's input device, used to pin the microphone to the earbuds. */
    fun bluetoothInput(): AudioDeviceInfo? =
        am.getDevices(AudioManager.GET_DEVICES_INPUTS).firstOrNull { isBtCommType(it.type) }

    /** Applies the route and returns the route actually in effect (falls back to PHONE). */
    fun apply(desired: Route): Route {
        requestFocus()
        var eff = desired
        if (eff == Route.HEADSET && !hasBluetoothAudio()) eff = Route.PHONE
        when (eff) {
            Route.HEADSET -> {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                if (Build.VERSION.SDK_INT >= 31) {
                    val dev = am.availableCommunicationDevices.firstOrNull { isBtCommType(it.type) }
                    if (dev == null || !am.setCommunicationDevice(dev)) {
                        eff = Route.PHONE
                        speaker()
                    }
                } else {
                    am.startBluetoothSco()
                    am.isBluetoothScoOn = true
                    scoOn = true
                }
                sleep(500) // let the Bluetooth voice link come up before recording starts
            }
            Route.EARBUDS -> am.mode = AudioManager.MODE_NORMAL
            Route.PHONE -> {
                am.mode = AudioManager.MODE_IN_COMMUNICATION
                speaker()
            }
        }
        return eff
    }

    fun release() {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                am.clearCommunicationDevice()
            } else if (scoOn) {
                am.stopBluetoothSco()
                am.isBluetoothScoOn = false
                scoOn = false
            }
            am.isSpeakerphoneOn = false
            am.mode = AudioManager.MODE_NORMAL
            focus?.let { am.abandonAudioFocusRequest(it) }
            focus = null
        } catch (_: Exception) {
        }
    }

    private fun speaker() {
        if (Build.VERSION.SDK_INT >= 31) {
            val dev = am.availableCommunicationDevices
                .firstOrNull { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER }
            if (dev != null) am.setCommunicationDevice(dev) else am.isSpeakerphoneOn = true
        } else {
            am.isSpeakerphoneOn = true
        }
    }

    private fun requestFocus() {
        if (focus != null) return
        val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setOnAudioFocusChangeListener { }
            .build()
        am.requestAudioFocus(req)
        focus = req
    }

    private fun sleep(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (_: InterruptedException) {
        }
    }
}
