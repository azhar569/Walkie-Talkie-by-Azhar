package com.walkie.p2p

/** Shared audio constants. 16 kHz mono, processed in 40 ms chunks (two 20 ms VAD sub-frames). */
object Audio {
    const val RATE = 16000
    const val SUB = 320      // 20 ms
    const val CHUNK = 640    // 40 ms = one network packet
}

/**
 * IMA/DVI ADPCM, 4 bits per sample (4:1 vs 16-bit PCM, ~65 kbit/s at 16 kHz).
 * Pure Kotlin: no native libraries, very low CPU, works on every device.
 * Every block carries its own predictor+index header, so a dropped or late block
 * never corrupts the ones after it.
 */
object Adpcm {
    const val HEADER = 3

    private val STEP = intArrayOf(
        7, 8, 9, 10, 11, 12, 13, 14, 16, 17, 19, 21, 23, 25, 28, 31, 34, 37, 41, 45, 50, 55, 60, 66,
        73, 80, 88, 97, 107, 118, 130, 143, 157, 173, 190, 209, 230, 253, 279, 307, 337, 371, 408,
        449, 494, 544, 598, 658, 724, 796, 876, 963, 1060, 1166, 1282, 1411, 1552, 1707, 1878, 2066,
        2272, 2499, 2749, 3024, 3327, 3660, 4026, 4428, 4871, 5358, 5894, 6484, 7132, 7845, 8630,
        9493, 10442, 11487, 12635, 13899, 15289, 16818, 18500, 20350, 22385, 24623, 27086, 29794,
        32767
    )
    private val ADJ = intArrayOf(-1, -1, -1, -1, 2, 4, 6, 8)

    class Encoder {
        private var pred = 0
        private var idx = 0

        fun reset() {
            pred = 0
            idx = 0
        }

        /** Encodes [count] samples (must be even). Returns the number of bytes written at [off]. */
        fun encode(pcm: ShortArray, count: Int, out: ByteArray, off: Int): Int {
            out[off] = (pred and 0xFF).toByte()
            out[off + 1] = ((pred shr 8) and 0xFF).toByte()
            out[off + 2] = idx.toByte()
            var o = off + HEADER
            var i = 0
            while (i + 1 < count) {
                val lo = sample(pcm[i].toInt())
                val hi = sample(pcm[i + 1].toInt())
                out[o++] = (lo or (hi shl 4)).toByte()
                i += 2
            }
            return o - off
        }

        private fun sample(s: Int): Int {
            var diff = s - pred
            var code = 0
            if (diff < 0) {
                code = 8
                diff = -diff
            }
            var step = STEP[idx]
            var delta = step shr 3
            if (diff >= step) {
                code = code or 4
                diff -= step
                delta += step
            }
            step = step shr 1
            if (diff >= step) {
                code = code or 2
                diff -= step
                delta += step
            }
            step = step shr 1
            if (diff >= step) {
                code = code or 1
                delta += step
            }
            pred += if ((code and 8) != 0) -delta else delta
            if (pred > 32767) pred = 32767
            if (pred < -32768) pred = -32768
            idx += ADJ[code and 7]
            if (idx < 0) idx = 0
            if (idx > 88) idx = 88
            return code
        }
    }

    /** Decodes a block (header + nibbles) into [out]. Returns the sample count, or 0 if invalid. */
    fun decode(data: ByteArray, off: Int, len: Int, out: ShortArray): Int {
        if (len <= HEADER) return 0
        val n = (len - HEADER) * 2
        if (n > out.size) return 0
        var pred = ((data[off + 1].toInt() shl 8) or (data[off].toInt() and 0xFF)).toShort().toInt()
        var idx = data[off + 2].toInt()
        if (idx < 0) idx = 0
        if (idx > 88) idx = 88
        var o = 0
        for (b in off + HEADER until off + len) {
            val byte = data[b].toInt() and 0xFF
            for (k in 0..1) {
                val code = if (k == 0) byte and 0x0F else byte shr 4
                val step = STEP[idx]
                var delta = step shr 3
                if ((code and 4) != 0) delta += step
                if ((code and 2) != 0) delta += step shr 1
                if ((code and 1) != 0) delta += step shr 2
                pred += if ((code and 8) != 0) -delta else delta
                if (pred > 32767) pred = 32767
                if (pred < -32768) pred = -32768
                idx += ADJ[code and 7]
                if (idx < 0) idx = 0
                if (idx > 88) idx = 88
                out[o++] = pred.toShort()
            }
        }
        return n
    }
}
