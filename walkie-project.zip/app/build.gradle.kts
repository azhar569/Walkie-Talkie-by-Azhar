plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.walkie.p2p"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.walkie.p2p"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            // Signed with the debug key so the APK installs directly (personal use).
            signingConfig = signingConfigs.getByName("debug")
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }

    lint {
        abortOnError = false
        checkReleaseBuilds = false
    }
}

dependencies {
    // Offline peer-to-peer transport (Bluetooth / BLE / Wi-Fi LAN / Wi-Fi Direct, no internet needed)
    implementation("com.google.android.gms:play-services-nearby:19.3.0")
}
